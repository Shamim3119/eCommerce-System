<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    protected $fillable = [
        'title',
        'sub_title',
        'description',
        'banner_image',
        'motto',
        'sort_order',
    ];
}
